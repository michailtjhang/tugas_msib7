

<?php $__env->startPush('metaSeO'); ?>
    <meta name="author" content="<?php echo e($article->user->name); ?>" />
    <meta name="description" content="<?php echo e(Str::limit(strip_tags($article->desc), 150, '...')); ?>" />
    <meta name="keywords" content="<?php echo e($article->title); ?> - <?php echo e(config('app.name', 'BlogSystem')); ?>">
    <meta name="og:title" content="<?php echo e($page_title ?? 'Blog'); ?> - <?php echo e(config('app.name', 'BlogSystem')); ?>">
    <meta name="og:description" content="<?php echo e(Str::limit(strip_tags($article->desc), 150, '...')); ?>">
    <meta name="og:url" content="<?php echo e(url()->current()); ?>">
    <meta name="og:image" content="<?php echo e(asset('storage/article/' . $article->img)); ?>">
    <meta name="og:site_name" content="Blog System">
    <meta name="og:type" content="article">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <!-- Featured blog post-->
                <div class="card mb-4" data-aos="fade-up">
                    <a href="<?php echo e(route('p', $article->slug)); ?>"><img class="card-img-top single-img"
                            src="<?php echo e(asset('storage/article/' . $article->img)); ?>" alt="<?php echo e($article->title); ?>" /></a>
                    <div class="card-body">
                        <div class="small text-muted">
                            <span class="ml-2"><?php echo e($article->created_at->format('M d, Y')); ?></span>
                            <span class="ml-2"><?php echo e($article->user->name ?? ''); ?></span>
                            <span class="ml-2"><a
                                    href="<?php echo e(route('category', $article->category->slug)); ?>"><?php echo e($article->category->name); ?></a></span>
                            <span class="ml-2">views <?php echo e($article->views); ?></span>
                        </div>
                        <h1 class="card-title"><?php echo e($article->title); ?></h1>
                        <p class="card-text"><?php echo $article->desc; ?></p>

                        <div class="mt-5">
                            <p style="font-size: 16px"><b>Share this article</b></p>

                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>"
                                class="btn btn-primary" target="_blank"><i class="fab fa-facebook"></i> Facebook</a></a>
                            <a href="https://api.whatsapp.com/send?text=<?php echo e(url()->current()); ?>" class="btn btn-success"
                                target="_blank"><i class="fab fa-whatsapp"></i> Whatsapp</a></a>
                        </div>
                        <div id="disqus_thread" class="mt-5"></div>
                    </div>
                </div>
            </div>

            <?php echo $__env->make('front.layouts.side-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        /**
         *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
         *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
        /*
        var disqus_config = function () {
        this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
        this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
        };
        */
        (function() { // DON'T EDIT BELOW THIS LINE
            var d = document,
                s = d.createElement('script');
            s.src = 'https://blogsytem.disqus.com/embed.js';
            s.setAttribute('data-timestamp', +new Date());
            (d.head || d.body).appendChild(s);
        })();
    </script>
    <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by
            Disqus.</a></noscript>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasMSIB7\Day_27\resources\views/front/article/show.blade.php ENDPATH**/ ?>