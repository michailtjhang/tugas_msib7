<div class="col-lg-4" data-aos="fade-left">
    <!-- Search widget-->
    <div class="card mb-4 shadow-sm">
        <div class="card-header">Search</div>
        <div class="card-body">
            <form action="<?php echo e(route('search')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <input class="form-control" type="text" name="keyword" placeholder="Search Articles..." />
                    <button class="btn btn-primary" id="button-search" type="submit">Search!</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Categories widget-->
    <div class="card mb-4 shadow-sm">
        <div class="card-header">Categories</div>
        <div class="card-body">
            <div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><a href="<?php echo e(route('category', $item->slug)); ?>"
                            class="badge bg-primary text-white unstyled-link"><?php echo e($item->name); ?> (<?php echo e($item->articles_count); ?>)</a></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <!-- Side widget-->
    <div class="card mb-4 shadow-sm">
        <div class="card-header">Side Widget</div>
        <div class="card-body">
            <a href="<?php echo e($config['ads_wight']); ?>" target="_blank" rel="noopener noreferrer">
                <img src="<?php echo e($config['ads_wight']); ?>" alt="ads_widget" class="img-fluid" width="50%">
            </a>
        </div>
    </div>

    <!-- Popular Articles-->
    <div class="card mb-4 shadow-sm">
        <div class="card-header">Popular Articles</div>
        <div class="card-body">
            <?php $__currentLoopData = $popular_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3">
                    <div class="row">
                        <div class="col-md-4">
                            <a href="<?php echo e(route('p', $item->slug)); ?> class="p-2"><img class="img-fluid"
                                    src="<?php echo e(asset('storage/article/' . $item->img)); ?>" alt="<?php echo e($item->title); ?>" /></a>
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <div class="card-title">
                                    <p><a href="<?php echo e(route('p', $item->slug)); ?>"
                                            class="unstyled-link"><?php echo e($item->title); ?></a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\tugasMSIB7\Day_27\resources\views/front/layouts/side-widget.blade.php ENDPATH**/ ?>