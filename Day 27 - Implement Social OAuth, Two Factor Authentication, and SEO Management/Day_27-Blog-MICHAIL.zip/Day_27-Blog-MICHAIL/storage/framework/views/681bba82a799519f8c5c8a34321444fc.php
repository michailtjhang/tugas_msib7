

<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container">

        <p>Showing all results with Category</p>

        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 mb-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <div class="text-center">
                                <a href="<?php echo e(route('category', $item->slug)); ?>" class="unstyled-link text-dark">
                                    <span>
                                        <i class="fas fa-folder fa-4x"></i>
                                    </span>
                                    <h5 class="card-title mt-2">
                                        <?php echo e($item->name); ?> ( <?php echo e($item->articles_count); ?> )
                                    </h5>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasMSIB7\Day_27\resources\views/front/category/all-category.blade.php ENDPATH**/ ?>