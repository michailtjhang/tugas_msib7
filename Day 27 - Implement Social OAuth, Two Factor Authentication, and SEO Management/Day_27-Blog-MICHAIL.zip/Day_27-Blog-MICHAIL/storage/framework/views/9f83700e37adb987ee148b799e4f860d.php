
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('article.index')); ?>">Article List </a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($page_title); ?></li>
            </ol>
        </nav>
        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-bordered table-hover table-stripped">
                    <tr>
                        <th>Title</th>
                        <td>: <?php echo e($article->title); ?></td>
                    </tr>
                    <tr></tr>
                    <th>Category</th>
                    <td>: <?php echo e($article->category->name); ?></td>
                    </tr>
                    <tr>
                        <th>Description</th>
                        <td>: <?php echo $article->desc; ?></td>
                    </tr>
                    <tr>
                        <th>Image</th>
                        <td>
                            <a href="<?php echo e(asset('storage/article/' . $article->img)); ?>" target="_blank"
                                rel="noopener noreferrer">
                                <img src="<?php echo e(asset('storage/article/' . $article->img)); ?>" alt="" width="500">
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <th>Views</th>
                        <td>: <?php echo e($article->views); ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <?php if($article->status == 1): ?>
                            <td>: <span class="badge badge-success">Published</span></td>
                        <?php else: ?>
                            <td>: <span class="badge badge-danger">Draft</span></td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <th>Published Date</th>
                        <td>: <?php echo e($article->published_date); ?></td>
                    </tr>
                    <tr>
                        <th>Writer</th>
                        <td>: <?php echo e($article->user->name ?? ''); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasMSIB7\Day_27\resources\views/admin/article/show.blade.php ENDPATH**/ ?>