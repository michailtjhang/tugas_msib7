

<?php $__env->startPush('metaSeO'); ?>
    <meta name="author" content="BlogSystem" />
    <meta name="description" content="Blog System, Seputar Informasi Teknologi, Artis, Model, Idol dan sejenisnya Terbaru" />
    <meta name="keywords" content="BlogSystem, informasi">
    <meta name="og:title" content="<?php echo e($page_title ?? 'Blog'); ?> - <?php echo e(config('app.name', 'BlogSystem')); ?>">
    <meta name="og:description" content="Blog System, Seputar Informasi Teknologi, Artis, Model, Idol dan sejenisnya Terbaru">
    <meta name="og:url" content="<?php echo e(url()->current()); ?>">
    <meta name="og:site_name" content="Blog System">
    <meta name="og:type" content="website">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <!-- Featured blog post-->
                <div class="card mb-4 shadow-sm" data-aos="fade-in">
                    <a href="<?php echo e(route('p', $last_articles->slug)); ?>"><img class="card-img-top feature-img"
                            src="<?php echo e(asset('storage/article/' . $last_articles->img)); ?>"
                            alt="<?php echo e($last_articles->title); ?>" /></a>
                    <div class="card-body">
                        <div class="small text-muted">
                            <?php echo e($last_articles->created_at->format('M d, Y')); ?>

                            |
                            <a href="<?php echo e(route('category', $last_articles->category->slug)); ?>">
                                <?php echo e($last_articles->category->name); ?>

                            </a>
                            |
                            <?php echo e($last_articles->user->name ?? ''); ?>

                        </div>
                        <h2 class="card-title"><?php echo e($last_articles->title); ?></h2>
                        <p class="card-text"><?php echo e(Str::limit(strip_tags($last_articles->desc), 200, '...')); ?></p>
                        <a class="btn btn-primary" href="<?php echo e(route('p', $last_articles->slug)); ?>">Read more →</a>
                    </div>
                </div>
                <!-- Nested row for non-featured blog posts-->
                <div class="row">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6" data-aos="fade-up">
                            <!-- Blog post-->

                            <div class="card mb-4 shadow-sm">
                                <a href="<?php echo e(route('p', $item->slug)); ?>"><img class="card-img-top post-img"
                                        src="<?php echo e(asset('storage/article/' . $item->img)); ?>" alt="..." /></a>
                                <div class="card-body card-height">
                                    <div class="small text-muted">
                                        <?php echo e($item->created_at->format('M d, Y')); ?>

                                        |
                                        <a href="<?php echo e(route('category', $item->category->slug)); ?>">
                                            <?php echo e($item->category->name); ?>

                                        </a>
                                        |
                                        <?php echo e($item->user->name ?? ''); ?>

                                    </div>
                                    <h2 class="card-title h4"><?php echo e($item->title); ?></h2>
                                    <p class="card-text"><?php echo e(Str::limit(strip_tags($item->desc), 100, '...')); ?></p>
                                    <a class="btn btn-primary" href="<?php echo e(route('p', $item->slug)); ?>">Read more →</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="pagination justify-content-center my-4">
                    <?php echo e($articles->links()); ?>

                </div>
            </div>

            <!-- Side widgets-->
            <?php echo $__env->make('front.layouts.side-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasMSIB7\Day_27\resources\views/front/home/index.blade.php ENDPATH**/ ?>