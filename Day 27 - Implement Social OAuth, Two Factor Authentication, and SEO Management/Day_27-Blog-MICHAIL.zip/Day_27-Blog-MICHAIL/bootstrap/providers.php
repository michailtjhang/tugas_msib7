<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\SideWidgetProvider::class,
    App\Providers\TemplateProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
];
