-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 06 Okt 2024 pada 05.57
-- Versi server: 8.0.30
-- Versi PHP: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `msib7_blog`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `articles`
--

CREATE TABLE `articles` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `category_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `views` int NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `articles`
--

INSERT INTO `articles` (`id`, `user_id`, `category_id`, `title`, `slug`, `desc`, `img`, `views`, `status`, `published_date`, `created_at`, `updated_at`) VALUES
(8, 1, 1, 'Zoom Metting 2', 'zoom-metting-2', '<p>Halo semua</p>\r\n\r\n<p><strong>Zoom bersama mentor</strong></p>\r\n\r\n<p><img alt=\"\" src=\"http://127.0.0.1:8000/storage/photos/Image/Gambar WhatsApp 2023-12-10 pukul 14.34.07_ba9a2a42.jpg\" style=\"height:508px; width:766px\" /></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>\r\n\r\n<p>Kamu dan</p>\r\n\r\n<p>saya</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?<br />\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66fcc9fad0739.jpg', 4, '1', '2024-10-02', '2024-10-01 21:20:10', '2024-10-03 19:42:28'),
(9, NULL, 1, 'Gmeet metting', 'gmeet-metting', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66fcd1ee418db.jpg', 1, '0', '2024-10-03', '2024-10-01 21:54:06', '2024-10-03 00:26:46'),
(10, NULL, 1, 'Zoom Metting kelompok', 'zoom-metting-kelompok', '<h2>Zoom Metting</h2>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66fcd21ece3c8.jpg', 0, '1', '2024-10-16', '2024-10-01 21:54:54', '2024-10-03 00:25:44'),
(11, NULL, 5, 'Yupi', 'yupi', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66fe46cbdabfe.jpg', 22, '1', '2024-10-03', '2024-10-03 00:24:59', '2024-10-03 19:42:52'),
(12, NULL, 4, 'Han so hee', 'han-so-hee', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66fe4776d8b1e.jpg', 4, '1', '2024-10-03', '2024-10-03 00:27:50', '2024-10-03 20:24:29'),
(13, 2, 5, 'Bona', 'bona', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66fe47a378b91.jpg', 17, '1', '2024-10-03', '2024-10-03 00:28:35', '2024-10-05 22:55:59'),
(14, 1, 7, 'Fiony', 'fiony', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66fe47c543232.jpeg', 125, '0', '2024-10-03', '2024-10-03 00:29:09', '2024-10-03 20:03:57'),
(15, 1, 7, 'Ryujin', 'ryujin', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo asperiores animi repudiandae distinctio, impedit exercitationem, tempore libero, cumque veniam quod deleniti tempora cupiditate amet numquam eos eum saepe? Autem, pariatur perspiciatis explicabo totam non architecto illum culpa harum cupiditate repudiandae voluptatem iure reiciendis sapiente fugit nesciunt doloremque eaque, possimus dolorum?</p>', '66ff604699d3b.jpg', 18, '1', '2024-10-04', '2024-10-03 20:25:58', '2024-10-05 22:55:23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Teknologi', 'teknologi', '2024-09-30 23:28:34', '2024-10-04 03:08:02'),
(2, 'Kesehatan', 'kesehatan', '2024-09-30 23:31:12', '2024-09-30 23:41:25'),
(4, 'Artis', 'artis', '2024-10-03 00:25:12', '2024-10-03 00:25:12'),
(5, 'Model', 'model', '2024-10-03 00:25:19', '2024-10-03 00:25:19'),
(6, 'Anime', 'anime', '2024-10-03 19:41:31', '2024-10-03 19:41:31'),
(7, 'Idol', 'idol', '2024-10-03 19:41:42', '2024-10-03 19:41:42'),
(8, 'Event', 'event', '2024-10-03 19:42:00', '2024-10-03 19:42:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `configs`
--

CREATE TABLE `configs` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `configs`
--

INSERT INTO `configs` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'logo', 'logo.png', NULL, NULL),
(2, 'blogname', 'BlogSystem', NULL, NULL),
(3, 'title', 'Welcome to BlogSystem!', NULL, NULL),
(4, 'caption', 'BlogSystem is a simple blog system with Laravel and Bootstrap.', NULL, NULL),
(5, 'ads_wight', 'https://images.unsplash.com/photo-1704299059700-268345bcb6bd?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', NULL, NULL),
(6, 'ads_header', 'adsense 2', NULL, NULL),
(7, 'ads_footer', 'adsense 3', NULL, NULL),
(8, 'phone', '+6281234567890', NULL, NULL),
(9, 'email', 'QW8kA@example.com', NULL, NULL),
(10, 'facebook', 'https://facebook.com', NULL, NULL),
(11, 'instagram', 'https://instagram.com', NULL, NULL),
(12, 'youtube', 'https://youtube.com', NULL, NULL),
(13, 'footer', 'BlogSystem', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_10_01_055107_create_categories_table', 2),
(5, '2024_10_01_055150_create_articles_table', 2),
(6, '2024_10_03_014814_add_role_to_users_table', 3),
(7, '2024_10_03_033435_add_provider_tokens_to_users_table', 4),
(8, '2024_10_03_035617_add_provider_name_to_users_table', 5),
(9, '2024_10_03_042914_add_two_factor_code_to_users_table', 6),
(10, '2024_10_03_051301_add_two_factor_enabled_to_users_table', 7),
(11, '2024_10_04_030640_add_user_id_to_articles_table', 8),
(12, '2024_10_04_040426_create_configs_table', 9);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('atLRESdRLWDX7aOXpSWZ4KN6mO7DgpE6Z5x3bsFD', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidkxKc1czNkFYb2I1YmxlMU9DaE9GWWd2a1lnM3lubW5IQzVrb2c5QSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9wL3J5dWppbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1728194056),
('kN2zNhBtsq0bkCum6YNck4aiFKmkt9fLbworIJ84', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVZqWHNZbGNQSVd6T0dtUEJSbTFPNkdEUTVQelFMWEJxMXEyU0pnVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9wL2JvbmEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1728194159),
('slRIe3CosT5jg2gp9m56G0pituyDDDRzOJ6j9SrU', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieDY4UDh1WkdpZmZQT0Z0V3J3dGI3UlY3dnRkRU04RUZpaVlseXB5WCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9jb250YWN0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1728038481);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` enum('user','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `provider_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_token` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_code` int DEFAULT NULL,
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`, `provider_id`, `access_token`, `refresh_token`, `provider_name`, `two_factor_code`, `two_factor_enabled`) VALUES
(1, 'Michail', 'admin@gmail.com', NULL, '$2y$12$9wjsL9qFznoUMQmLd7JE3eczDi0sqmCyCdPXrb4HX0mZozkrK1GpC', '9vI2QDGF10k7aBGwX2KCpzEfBNyDv4orMJ1vnR0LT8x3TXibzShCZvKvIjtx', '2024-10-02 18:35:52', '2024-10-03 00:23:49', 'admin', NULL, NULL, NULL, NULL, NULL, 0),
(2, 'Budi', 'budi@gmail.com', NULL, '$2y$12$VNYWfXDT4xF7hI.4rka7ZuYE3HK005mBL6jRYJ8XvQlZZiLGtyLiu', 'VfYJYrmarm4IjEDwH5eiBaAIUZhXzNEY4PQhhkDffv8UJrvOUQhldrXOkiZR', '2024-10-02 18:44:05', '2024-10-02 18:44:05', 'user', NULL, NULL, NULL, NULL, NULL, 0),
(6, 'Valeska Stewart', 'valeskastw39@gmail.com', NULL, '$2y$12$oUUSWg268ZW.RWxvAn2lQ.HLiMsw/rK9Yhmx5SWbbNfmfPdCq/Ed.', NULL, '2024-10-02 21:01:13', '2024-10-02 21:01:13', 'user', '116550131377156304252', 'ya29.a0AcM612yzY7z9lKSZWa9oKa_vvEoTHmyITvbG-HvtuNZ-DpwugMCZXQhROqu32Yag-X5T2buZa5t35ApC4oRx9OgguUYcEpRrhsUp7FaEYTukzacmDCCX0igQFIH8nadRQmArn5jrrIyfCs_V4qQsGb6mOmpz0-apYAaCgYKAYkSARASFQHGX2Mi1edZdJjWWXDVY0yMXuBXUQ0169', NULL, 'google', NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `articles_category_id_index` (`category_id`),
  ADD KEY `articles_user_id_foreign` (`user_id`);

--
-- Indeks untuk tabel `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `configs`
--
ALTER TABLE `configs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indeks untuk tabel `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indeks untuk tabel `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `articles`
--
ALTER TABLE `articles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `configs`
--
ALTER TABLE `configs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `articles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
