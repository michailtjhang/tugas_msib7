<?php

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "msib7_webscraping";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fungsi web scraping
function _retriever($url, $data = null, $headers = null, $method = "GET")
{
    $cookie_file_temp = dirname(__FILE__) . '/cookie/name.txt';
    $datas['http_code'] = 0;

    if ($url == "") {
        return $datas;
    }

    $data_string = "";
    if ($data != null) {
        foreach ($data as $key => $value) {
            $data_string .= $key . '=' . urlencode($value) . '&';
        }
        $data_string = rtrim($data_string, '&');
    }

    $ch = curl_init();

    if (strtoupper($method) == "POST") {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    } else if (strtoupper($method) == "GET" && $data != null) {
        $url = $url . '?' . $data_string;
    }

    if ($headers != null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_NOBODY, false);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_temp);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_temp);

    $response = curl_exec($ch);
    $datas['http_code'] = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $datas['content'] = $response;

    if (curl_errno($ch)) {
        $datas['error'] = curl_error($ch);
    }

    curl_close($ch);

    return $datas;
}

$url = "https://mercuryfm.id/";
$html = _retriever($url);

$t_start = strpos($html['content'], '<div class="jeg_postblock_content">');
$t_html = substr($html['content'], $t_start);

$dom = new DOMDocument();
@$dom->loadHTML($t_html);

$xpath = new DOMXPath($dom);

$articles = $xpath->query('//article[contains(@class, "jeg_post")]');

foreach ($articles as $article) {
    // Ambil link artikel
    $link = $xpath->query('.//div[@class="jeg_postblock_content"]/h3[@class="jeg_post_title"]/a', $article);
    if ($link->length > 0) {
        $articleLink = $link->item(0)->getAttribute('href');
        $articleTitle = $link->item(0)->nodeValue;
    } else {
        $articleLink = "Link tidak ditemukan";
        $articleTitle = "Judul tidak ditemukan";
    }

    // Ambil link gambar dari atribut data-src
    $image = $xpath->query('.//div[@class="jeg_thumb"]/a/div/img', $article);
    if ($image->length > 0) {
        $articleImage = $image->item(0)->getAttribute('data-src');
    } else {
        $articleImage = "Gambar tidak ditemukan";
    }

    // Ambil tanggal artikel
    $date = $xpath->query('.//div[@class="jeg_post_meta"]/div[@class="jeg_meta_date"]/a', $article);
    if ($date->length > 0) {
        $articleDate = date('Y-m-d', strtotime($date->item(0)->nodeValue));
    } else {
        $articleDate = "Tanggal tidak ditemukan";
    }

    // Simpan hasil ke database
    $stmt = $conn->prepare("INSERT INTO articles (title, link, image, date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $articleTitle, $articleLink, $articleImage, $articleDate);

    if ($stmt->execute()) {
        echo "Data inserted successfully.<br>";
    } else {
        echo "Error: " . $stmt->error . "<br>";
    }
}

$conn->close();
