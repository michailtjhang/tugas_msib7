<?php

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "msib7_webscraping";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fungsi web scraping
function _retriever($url, $data = null, $headers = null, $method = "GET") {
    $cookie_file_temp = dirname(__FILE__) . '/cookie/name.txt';
    $datas['http_code'] = 0;

    if ($url == "") {
        return $datas;
    }

    $data_string = "";
    if ($data != null) {
        foreach ($data as $key => $value) {
            $data_string .= $key . '=' . urlencode($value) . '&';
        }
        $data_string = rtrim($data_string, '&');
    }

    $ch = curl_init();

    if (strtoupper($method) == "POST") {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    } else if (strtoupper($method) == "GET" && $data != null) {
        $url = $url . '?' . $data_string;
    }

    if ($headers != null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_NOBODY, false);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_temp);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_temp);

    $response = curl_exec($ch);
    $datas['http_code'] = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $datas['content'] = $response;

    if (curl_errno($ch)) {
        $datas['error'] = curl_error($ch);
    }

    curl_close($ch);

    return $datas;
}

// Web scraping process
$url = "https://www.kapanlagi.com/showbiz/index.html";
$html = _retriever($url);

// Mengambil HTML untuk di parsing
$t_start = strpos($html['content'], '<div class="tag-header-warper">');
$t_html = substr($html['content'], $t_start);

$dom = new DOMDocument();
@$dom->loadHTML($t_html);
$xpath = new DOMXPath($dom);

$items = $xpath->query('//li[contains(@class, "tagli")]');

foreach ($items as $item) {
    $link = $xpath->query('.//a[@target="_blank"]', $item);
    $newsLink = $link->item(0)->getAttribute('href');

    $img = $xpath->query('.//img', $item);
    $newsImage = $img->item(0)->getAttribute('src');

    $titleLink = $xpath->query('.//div[@class="desc"]//a', $item);
    $newsTitle = $titleLink->item(0)->nodeValue;

    $htmlDetail = _retriever($newsLink);
    $decode = gzdecode($htmlDetail['content']);

    $script_start = strpos($decode, '<script type="application/ld+json">');
    $temp_html = substr($decode, $script_start);
    $script_end = strpos($temp_html, '</script>');
    $json = substr($temp_html, 35, $script_end-35);
    $arr_data = json_decode($json);

    $publishDate = isset($arr_data[2]->datePublished) ? $arr_data[2]->datePublished : null;
    $articleBody = isset($arr_data[2]->articleBody) ? $arr_data[2]->articleBody : null;
    $keywords = '';
    if (isset($arr_data[2]->keywords)) {
        foreach ($arr_data[2]->keywords as $value) {
            $keywords .= $value . ', ';
        }
        $keywords = rtrim($keywords, ', ');
    }

    // Menyimpan hasil ke dalam database
    $stmt = $conn->prepare("INSERT INTO news (title, link, image, publish, articleBody, keywords) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $newsTitle, $newsLink, $newsImage, $publishDate, $articleBody, $keywords);

    if ($stmt->execute()) {
        echo "Data inserted successfully.<br>";
    } else {
        echo "Error: " . $stmt->error . "<br>";
    }
}

$conn->close();
