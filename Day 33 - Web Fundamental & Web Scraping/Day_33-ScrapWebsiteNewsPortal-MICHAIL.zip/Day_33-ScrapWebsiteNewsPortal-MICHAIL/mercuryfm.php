<?php

function _retriever($url, $data = null, $headers = null, $method = "GET")
{
    $cookie_file_temp = dirname(__FILE__) . '/cookie/name.txt';
    $datas['http_code'] = 0;

    // Check if URL is empty
    if ($url == "") {
        return $datas;
    }

    // Prepare data for POST or GET
    $data_string = "";
    if ($data != null) {
        foreach ($data as $key => $value) {
            $data_string .= $key . '=' . urlencode($value) . '&';
        }
        $data_string = rtrim($data_string, '&');
    }

    // Initialize cURL
    $ch = curl_init();

    // Set request method
    if (strtoupper($method) == "POST") {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    } else if (strtoupper($method) == "GET" && $data != null) {
        $url = $url . '?' . $data_string;
    }

    // Set headers if provided
    if ($headers != null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    // Set other cURL options
    curl_setopt($ch, CURLOPT_HEADER, false); // Exclude the header in the output
    curl_setopt($ch, CURLOPT_NOBODY, false); // Include the body in the output
    curl_setopt($ch, CURLOPT_URL, $url); // Set the URL to fetch
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // Ignore host SSL verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Ignore peer SSL verification
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return output as string
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow any "Location: " header
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_temp); // Save cookies
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_temp); // Send cookies

    // Execute cURL request
    $response = curl_exec($ch);
    $datas['http_code'] = curl_getinfo($ch, CURLINFO_HTTP_CODE); // Get HTTP response code
    $datas['content'] = $response; // Get response content

    // Check for cURL errors
    if (curl_errno($ch)) {
        $datas['error'] = curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    return $datas;
}

$data = array();
$counter = 0;

$url = "https://mercuryfm.id/";
$html = _retriever($url);

// print_r($html['content']);

// content utama
$t_start = strpos($html['content'], '<div class="jeg_postblock_content">');
$t_html = substr($html['content'], $t_start);

// Inisialisasi DOMDocument dan muat HTML
$dom = new DOMDocument();
@$dom->loadHTML($t_html);

// Inisialisasi DOMXPath untuk memudahkan pencarian elemen
$xpath = new DOMXPath($dom);

// Ambil link kategori
$category_link = $xpath->query('//div[@class="jeg_post_category"]/span/a')->item(0)->getAttribute('href');
print_r("Category Link: " . $category_link . "<br>");

// Ambil judul dan link artikel
$title_link = $xpath->query('//h3[@class="jeg_post_title"]/a');
$article_link = $title_link->item(0)->getAttribute('href');
$article_title = $title_link->item(0)->nodeValue;

print_r("Article Link: " . $article_link . "<br>");
print_r("Article Title: " . $article_title . "<br>");

// Ambil tanggal artikel
$date = $xpath->query('//div[@class="jeg_post_meta"]//div[@class="jeg_meta_date"]/a')->item(0)->nodeValue;
print_r("Article Date: " . $date . "<br>");


$t_start = strpos($html['content'], '<div class="jeg_posts jeg_load_more_flag">');
$t_html = substr($html['content'], $t_start);

// Inisialisasi DOMDocument dan muat HTML
$dom = new DOMDocument();
@$dom->loadHTML($t_html);

// Inisialisasi DOMXPath untuk memudahkan pencarian elemen
$xpath = new DOMXPath($dom);

// Ambil semua elemen artikel dengan class "jeg_post"
$articles = $xpath->query('//article[contains(@class, "jeg_post")]');

foreach ($articles as $article) {
    // Ambil link artikel
    $link = $xpath->query('.//div[@class="jeg_postblock_content"]/h3[@class="jeg_post_title"]/a', $article);
    $articleLink = $link->item(0)->getAttribute('href');

    // Ambil judul artikel
    $articleTitle = $link->item(0)->nodeValue;

    // Ambil link gambar dari atribut data-src
    $image = $xpath->query('.//div[@class="jeg_thumb"]/a/div/img', $article);
    $articleImage = $image->item(0)->getAttribute('data-src');
    
    // Ambil tanggal artikel
    $date = $xpath->query('.//div[@class="jeg_post_meta"]/div[@class="jeg_meta_date"]/a', $article);
    $articleDate = $date->item(0)->nodeValue;

    print_r(("<li>" . $articleTitle . "</li>"));
    print_r("<ol><li>" . $articleLink . "</li><li>" . $articleImage . "</li><li>" . $articleDate . "</li></ol><br>");
}