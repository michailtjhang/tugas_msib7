<?php

function _retriever($url, $data = null, $headers = null, $method = "GET")
{
    $cookie_file_temp = dirname(__FILE__) . '/cookie/pwntilldawn.txt';
    $datas = [
        'http_code' => 0,
        'content' => '',
        'error' => ''
    ];

    // Check if URL is empty
    if ($url == "") {
        return $datas;
    }

    // Prepare data for POST or GET
    $data_string = "";
    if ($data != null) {
        foreach ($data as $key => $value) {
            $data_string .= $key . '=' . urlencode($value) . '&';
        }
        $data_string = rtrim($data_string, '&');
    }

    // Initialize cURL
    $ch = curl_init();

    // Set request method
    if (strtoupper($method) == "POST") {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    } elseif (strtoupper($method) == "GET" && $data != null) {
        $url = $url . '?' . $data_string;
    } elseif ($method != "GET" && $method != "POST") {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    }

    // Set headers if provided
    if ($headers != null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    // Set other cURL options
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_NOBODY, false);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_temp);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_temp);

    // Execute cURL request
    $response = curl_exec($ch);
    $datas['http_code'] = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $datas['content'] = $response;

    // Check for cURL errors
    if (curl_errno($ch)) {
        $datas['error'] = curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    return $datas;
}

$html = _retriever("https://online.pwntilldawn.com/Account/Login");

// Token
$start_token = strpos($html['content'], '<input name="__RequestVerificationToken"')+62;
$end_token = strpos($html['content'], '" /> <script type="text/javascript" style="display:none">');
$token = substr($html['content'], $start_token, $end_token - $start_token);

$data = array(
    '__RequestVerificationToken' => $token,
    "Email" => "",
    "Password" => "",
);

$header = array(
    'origin: https://online.pwntilldawn.com',
    'referer: https://online.pwntilldawn.com/Account/Login?ReturnUrl=%2f'
);

$html = _retriever("https://online.pwntilldawn.com/Account/Login?ReturnUrl=%2F", $data, $header, "POST");

print_r($html);
