<?php
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Farm RPG - AUTOFARM</title>
</head>

<body>

</body>

</html>

<script>
    $(document).ready(function() {
        function autoFarm() {

            var url = "farmrpg.php";
            $.ajax({
                method: "GET",
                dataType: "json",
                url: url,
                contentType: "application/json; charset=utf-8",
                success: function(data) {
                    console.log(data);
                    setTimeout(autoFarm, 61000)
                },
                error: function(e) {
                    console.log(e.message);
                }
            })
        }

        autoFarm();
    })
</script>